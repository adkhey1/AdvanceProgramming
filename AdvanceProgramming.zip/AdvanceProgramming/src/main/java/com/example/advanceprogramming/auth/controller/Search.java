package com.example.advanceprogramming.auth.controller;

public class Search {
    private String pName;
    private String lName;

    public String getLName() {
        return lName;
    }

    public void setLName(String lName) {
        this.lName = lName;
    }

    public void setPName(String pName) {
        this.pName = pName;
    }

    public String getPName() {
        return pName;
    }
}
