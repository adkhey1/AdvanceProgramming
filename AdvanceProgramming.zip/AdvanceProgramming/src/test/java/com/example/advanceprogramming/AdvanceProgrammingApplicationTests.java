package com.example.advanceprogramming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvanceProgrammingApplicationTests {

    @Test
    void contextLoads() {
    }

}
